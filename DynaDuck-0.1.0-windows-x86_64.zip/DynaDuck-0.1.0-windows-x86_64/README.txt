DynaDuck 2006 0.1.0 (Windows x86_64)
=====================================

A blocky 2006-style avatar playground. Your avatar colors load
live from Firebase (users/<name>/colors).

RUN
  Linux:   ./DynaDuck [username]      (default username: Admin)
  Windows: DynaDuck.exe [username]

CONTROLS
  WASD ............ move (camera-relative)
  Space ........... jump (arms up, old style)
  Mouse right-drag  orbit camera
  Mouse wheel ..... zoom (5-16)
  Arrow keys ...... orbit camera
  1-6 ............. toolbar slots

REQUIREMENTS
  None - just unzip and run setup.bat (Windows 10+ has curl built in for avatar colors)

FILES (keep together, same folders!)
  DynaDuck(.exe) ......... the game
  head.glb ............... head mesh
  face.png ............... face decal
  third_party/font_atlas.png ... UI font (Arial)
  glfw3.dll .............. (Windows only, beside the .exe)
