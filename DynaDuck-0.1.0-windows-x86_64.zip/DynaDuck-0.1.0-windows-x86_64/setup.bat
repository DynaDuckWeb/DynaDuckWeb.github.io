@echo off
REM DynaDuck official Windows setup - installs to %LOCALAPPDATA%\DynaDuck
setlocal
set DEST=%LOCALAPPDATA%\DynaDuck
echo Installing DynaDuck to %DEST% ...
mkdir "%DEST%" 2>nul
mkdir "%DEST%\third_party" 2>nul
copy /Y DynaDuck.exe "%DEST%\" >nul
copy /Y glfw3.dll "%DEST%\" >nul
copy /Y head.glb "%DEST%\" >nul
copy /Y face.png "%DEST%\" >nul
copy /Y logo.png "%DEST%\" >nul
copy /Y DynaDuck.ico "%DEST%\" >nul
copy /Y third_party\font_atlas.png "%DEST%\third_party\" >nul
mkdir "%DEST%\sky" 2>nul
mkdir "%DEST%\texture" 2>nul
copy /Y sky\*.jpg "%DEST%\sky\" >nul
copy /Y texture\stud.png "%DEST%\texture\" >nul
if errorlevel 1 (
  echo INSTALL FAILED - keep all files together and run again.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\DynaDuck.lnk'); $s.TargetPath='%DEST%\DynaDuck.exe'; $s.WorkingDirectory='%DEST%'; $s.IconLocation='%DEST%\DynaDuck.ico'; $s.Save()"
powershell -NoProfile -ExecutionPolicy Bypass -Command "New-Item -Path 'HKCU:\Software\Classes\dynaduck' -Force | Out-Null; Set-ItemProperty -Path 'HKCU:\Software\Classes\dynaduck' -Name '(Default)' -Value 'URL:DynaDuck'; Set-ItemProperty -Path 'HKCU:\Software\Classes\dynaduck' -Name 'URL Protocol' -Value ''; New-Item -Path 'HKCU:\Software\Classes\dynaduck\shell\open\command' -Force | Out-Null; Set-ItemProperty -Path 'HKCU:\Software\Classes\dynaduck\shell\open\command' -Name '(Default)' -Value '\"%DEST%\DynaDuck.exe\" \"%%1\"'"
echo Done! Launch from the Desktop shortcut or run DynaDuck.exe in %DEST%
pause
